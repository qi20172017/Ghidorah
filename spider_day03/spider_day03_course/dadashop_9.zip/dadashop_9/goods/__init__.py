def index():
    return None