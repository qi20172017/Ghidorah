#设置cookie过期的时间
#一个月的过期时间
CART_COOKIE_EXPIRES = 30*24*60*60